Drivers/WIZnet/Ethernet/wizchip_conf.o: \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.c \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.h \
 ../Drivers/WIZnet/Ethernet/./W6100/w6100.h \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.h \
 ../Drivers/WIZnet/Ethernet/../Application/Application.h
../Drivers/WIZnet/Ethernet/wizchip_conf.h:
../Drivers/WIZnet/Ethernet/./W6100/w6100.h:
../Drivers/WIZnet/Ethernet/wizchip_conf.h:
../Drivers/WIZnet/Ethernet/../Application/Application.h:
