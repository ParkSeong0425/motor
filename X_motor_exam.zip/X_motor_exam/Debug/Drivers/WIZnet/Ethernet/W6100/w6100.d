Drivers/WIZnet/Ethernet/W6100/w6100.o: \
 ../Drivers/WIZnet/Ethernet/W6100/w6100.c \
 ../Drivers/WIZnet/Ethernet/W6100/w6100.h \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.h \
 ../Drivers/WIZnet/Ethernet/./W6100/w6100.h \
 ../Drivers/WIZnet/Ethernet/../Application/Application.h
../Drivers/WIZnet/Ethernet/W6100/w6100.h:
../Drivers/WIZnet/Ethernet/wizchip_conf.h:
../Drivers/WIZnet/Ethernet/./W6100/w6100.h:
../Drivers/WIZnet/Ethernet/../Application/Application.h:
