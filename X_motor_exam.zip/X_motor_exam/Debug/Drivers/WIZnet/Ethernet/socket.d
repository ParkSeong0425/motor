Drivers/WIZnet/Ethernet/socket.o: ../Drivers/WIZnet/Ethernet/socket.c \
 ../Drivers/WIZnet/Ethernet/socket.h \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.h \
 ../Drivers/WIZnet/Ethernet/./W6100/w6100.h \
 ../Drivers/WIZnet/Ethernet/wizchip_conf.h \
 ../Drivers/WIZnet/Ethernet/../Application/Application.h \
 ../Drivers/WIZnet/Ethernet/W6100/w6100.h
../Drivers/WIZnet/Ethernet/socket.h:
../Drivers/WIZnet/Ethernet/wizchip_conf.h:
../Drivers/WIZnet/Ethernet/./W6100/w6100.h:
../Drivers/WIZnet/Ethernet/wizchip_conf.h:
../Drivers/WIZnet/Ethernet/../Application/Application.h:
../Drivers/WIZnet/Ethernet/W6100/w6100.h:
