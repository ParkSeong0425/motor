################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/WIZnet/Ethernet/socket.c \
../Drivers/WIZnet/Ethernet/wizchip_conf.c 

OBJS += \
./Drivers/WIZnet/Ethernet/socket.o \
./Drivers/WIZnet/Ethernet/wizchip_conf.o 

C_DEPS += \
./Drivers/WIZnet/Ethernet/socket.d \
./Drivers/WIZnet/Ethernet/wizchip_conf.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/WIZnet/Ethernet/%.o Drivers/WIZnet/Ethernet/%.su Drivers/WIZnet/Ethernet/%.cyclo: ../Drivers/WIZnet/Ethernet/%.c Drivers/WIZnet/Ethernet/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/WIZnet/Ethernet -I../Drivers/WIZnet/Ethernet/W6100 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-WIZnet-2f-Ethernet

clean-Drivers-2f-WIZnet-2f-Ethernet:
	-$(RM) ./Drivers/WIZnet/Ethernet/socket.cyclo ./Drivers/WIZnet/Ethernet/socket.d ./Drivers/WIZnet/Ethernet/socket.o ./Drivers/WIZnet/Ethernet/socket.su ./Drivers/WIZnet/Ethernet/wizchip_conf.cyclo ./Drivers/WIZnet/Ethernet/wizchip_conf.d ./Drivers/WIZnet/Ethernet/wizchip_conf.o ./Drivers/WIZnet/Ethernet/wizchip_conf.su

.PHONY: clean-Drivers-2f-WIZnet-2f-Ethernet

