################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/WIZnet/Internet/DNS/dns.c 

OBJS += \
./Drivers/WIZnet/Internet/DNS/dns.o 

C_DEPS += \
./Drivers/WIZnet/Internet/DNS/dns.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/WIZnet/Internet/DNS/%.o Drivers/WIZnet/Internet/DNS/%.su Drivers/WIZnet/Internet/DNS/%.cyclo: ../Drivers/WIZnet/Internet/DNS/%.c Drivers/WIZnet/Internet/DNS/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/WIZnet/Ethernet -I../Drivers/WIZnet/Ethernet/W6100 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-WIZnet-2f-Internet-2f-DNS

clean-Drivers-2f-WIZnet-2f-Internet-2f-DNS:
	-$(RM) ./Drivers/WIZnet/Internet/DNS/dns.cyclo ./Drivers/WIZnet/Internet/DNS/dns.d ./Drivers/WIZnet/Internet/DNS/dns.o ./Drivers/WIZnet/Internet/DNS/dns.su

.PHONY: clean-Drivers-2f-WIZnet-2f-Internet-2f-DNS

