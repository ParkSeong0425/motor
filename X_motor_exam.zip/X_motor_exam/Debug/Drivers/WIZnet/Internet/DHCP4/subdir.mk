################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/WIZnet/Internet/DHCP4/dhcpv4.c 

OBJS += \
./Drivers/WIZnet/Internet/DHCP4/dhcpv4.o 

C_DEPS += \
./Drivers/WIZnet/Internet/DHCP4/dhcpv4.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/WIZnet/Internet/DHCP4/%.o Drivers/WIZnet/Internet/DHCP4/%.su Drivers/WIZnet/Internet/DHCP4/%.cyclo: ../Drivers/WIZnet/Internet/DHCP4/%.c Drivers/WIZnet/Internet/DHCP4/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/WIZnet/Ethernet -I../Drivers/WIZnet/Ethernet/W6100 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-WIZnet-2f-Internet-2f-DHCP4

clean-Drivers-2f-WIZnet-2f-Internet-2f-DHCP4:
	-$(RM) ./Drivers/WIZnet/Internet/DHCP4/dhcpv4.cyclo ./Drivers/WIZnet/Internet/DHCP4/dhcpv4.d ./Drivers/WIZnet/Internet/DHCP4/dhcpv4.o ./Drivers/WIZnet/Internet/DHCP4/dhcpv4.su

.PHONY: clean-Drivers-2f-WIZnet-2f-Internet-2f-DHCP4

